<?php 
	include '../config.php';

	session_start();
	if (!isset($_SESSION['user_name'])) {
		header('Location: ../login.html');
		exit();
	}

 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Juego del Gato</title>
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="../assets/css/main.css">
</head>
<body>
	<div class="header-nav" style="">
		<p style="display: inline-block; width:50%; text-align: left; font-size: 30px"><a href="../index.php"><b>G</b>ame<b>b</b>ook</a></p>
		<p style="box-sizing: border-box; display: inline-block; width:45%; text-align: right; padding-right: 30px;"><?=$_SESSION['user_name']?>&nbsp&nbsp&nbsp<a href="../logout.php">Logout</a></p>
	</div>
	<div id="contenedor">
		<div id="">
			<div id="jugador">
				<label>Jugador 1(X):</label>
				<input type="text" id="j1">
				<label> Jugador 2(O):</label>
				<input type="text" id="j2">
			</div>
			<input type="button" onclick="start()" value="Iniciar">
			<div id="cuadricula">
				<table>
					<td>
						<tr>
							<input type="button" id="1" class="btn" onclick="ponerMarca(this.id)" disabled value="">
							<input type="button" id="2" class="btn" onclick="ponerMarca(this.id)" disabled value="">
							<input type="button" id="3" class="btn" onclick="ponerMarca(this.id)" disabled value="">
						</tr>
						<br>
						<tr>
							<input type="button" id="4" class="btn" onclick="ponerMarca(this.id)" disabled value="">
							<input type="button" id="5" class="btn" onclick="ponerMarca(this.id)" disabled value="">
							<input type="button" id="6" class="btn" onclick="ponerMarca(this.id)" disabled value="">
						</tr>
						<br>
						<tr>
							<input type="button" id="7" class="btn" onclick="ponerMarca(this.id)" disabled value="">
							<input type="button" id="8" class="btn" onclick="ponerMarca(this.id)" disabled value="">
							<input type="button" id="9" class="btn" onclick="ponerMarca(this.id)" disabled value="">
						</tr>
					</td>
				</table>
			</div>
		</div>
	</div>
	<script src="js/scripts.js"></script>
</body>
</html>
function start(e){
	var jgdr1 = document.getElementById('j1');
	var jgdr2 = document.getElementById('j2');

	if (jgdr1.value != '' && jgdr2.value != '') {
		var btns = document.getElementsByClassName("btn");
		for (i in btns) {
			btns[i].removeAttribute('disabled');
		}
	}
}

var marca = 'X';
function ponerMarca(x){
	var boton = document.getElementById(x);
	console.log(boton.value);
	if (boton.value == '') {
		document.getElementById(x).value = marca;
		if (marca == 'X') {
			marca = 'O';
		}else{
			marca = 'X';
		}
	}
}

function validarJuego(){
	
}
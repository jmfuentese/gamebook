<?php 
	include 'config.php';

	session_start();
	if (!isset($_SESSION['user_name'])) {
		header('Location: login.html');
		exit();
	}

 ?>
<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title>Space Invaders</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/main.css">
    <script data-main="assets/javascript/built/main-built.js" src="assets/javascript/lib/require.js"></script>
</head>
<body>
	<div class="header-nav" style="">
		<p style="display: inline-block; width:50%; text-align: left; font-size: 30px"><a href="../index.php"><b>G</b>ame<b>b</b>ook</a></p>
		<p style="box-sizing: border-box; display: inline-block; width:45%; text-align: right; padding-right: 30px;"><?=$_SESSION['user_name']?>&nbsp&nbsp&nbsp<a href="../logout.php">Logout</a></p>
	</div>
    <div id="game">
    </div>
</body>
</html>
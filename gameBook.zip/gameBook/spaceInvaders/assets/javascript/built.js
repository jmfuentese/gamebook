
({
    baseUrl: ".",
    name: "main",
    out: "built/main-built.js"
})
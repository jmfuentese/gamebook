define(['module/Background','module/Player','module/Aliens','module/Bullets','module/Explosions','module/HUD'],function(Background,Player,Aliens,Bullets,Explosions,HUD){
    
    var _game = null,
        _nextStage = null;
    
  
    var _Load = {        
        preload: function(){
        
            
            Background.init(_game,0,'easy');
            Background.preload();

         
            HUD.init(_game);

                      
            Player.init(_game);
            Player.preload();
            
    
            Aliens.init(_game);
            Aliens.preload();

        
            Bullets.init(_game);
            Bullets.preload();
            

            Explosions.init(_game);
            Explosions.preload();
                
        },
        create: function(){
            _game.state.start(_nextStage);
        }
    }
    
    return{
        init: function(game,nextStage){
            _game = game;
            _nextStage = nextStage;
        },
        getLoadState: function(){
            return(_Load);
        }
        
    }
})
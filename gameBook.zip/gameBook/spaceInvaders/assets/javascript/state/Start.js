define(['module/HUD'],function(HUD){
    var _game = null,
        _nextState = null,
        _activationKey = null;
    
    
    var _Start = {                    
        create: function(){
            //Pantalla inicio
            HUD.createTitle(' Space Invaders \n Presiona la barra espaciadora');
            
            //fisicas
            _game.physics.startSystem(Phaser.Physics.ARCADE); 
            
            
            _game.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR).onDown.addOnce(function(){
                _game.state.start(_nextState);
            });                        
        }            
    }

    return{
        init: function(game,nextState){
            _game = game;
            _nextState = nextState;
        },
        getStartState: function(){
            return(_Start);
        }

    }
})
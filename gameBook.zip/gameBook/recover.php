<?php  
	include 'config.php';
	$user = filter_input(INPUT_POST, 'user_name');